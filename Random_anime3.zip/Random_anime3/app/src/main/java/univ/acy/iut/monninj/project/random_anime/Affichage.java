package univ.acy.iut.monninj.project.random_anime;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.DownloadListener;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Affichage extends AppCompatActivity {

    private final static String TAG=Affichage.class.getName();

    private String animetitle=null;
    private String synopsys=null;
    private String link=null;
    private String image=null;
    public TextView AnimeTitre;
    public ImageView AnimeImage;
    public TextView AnimeSynopsys;
    public Bitmap ImageDL;
    private int id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG,"onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage);
        Intent intent = super.getIntent();
        this.id = intent.getIntExtra("ID",0);
        Connexion connection = new Connexion(id,this);
        this.AnimeTitre = super.findViewById(R.id.anime_titre);
        this.AnimeImage = super.findViewById(R.id.anime_image);
        this.AnimeSynopsys = super.findViewById(R.id.anime_synopsys);
    }

    @Override
    protected void onStart() {
        Log.i(TAG,"onStart");
        super.onStart();


    }

    @Override
    protected void onResume() {
        Log.i(TAG,"onResume");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.i(TAG,"onPause");

        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.i(TAG,"onStop");
        super.onStop();
    }

    @Override
    protected void onRestart() {
        Log.i(TAG,"onRestart");
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG,"onDestroy");
        super.onDestroy();
    }
    public void take(String chaine){
        JSONObject anime = null;
        try {
            anime = new JSONObject(chaine);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        try {
            setAnimetitle(animetitle = anime.getString("title"));
            setSynopsys(synopsys = anime.getString("synopsis"));
            setLink(link = anime.getString("link"));
            setImage(image = anime.getString("image_url"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.i(TAG,"title = "+this.getAnimetitleTitle());
        Log.i(TAG,"synopsys = "+this.synopsys);
        Log.i(TAG,"link = "+this.link);
        Log.i(TAG,"image = "+this.image);


        try {
            Log.i(TAG,"connexion");
            URL url = new URL(this.image);
            HttpURLConnection connex = (HttpURLConnection) url.openConnection();
            connex.setDoInput(true);
            connex.setConnectTimeout(3000);
            connex.connect();
            InputStream in = connex.getInputStream();
            this.ImageDL = BitmapFactory.decodeStream(in);
            Log.i(TAG,"Terminé");
        } catch (IOException e) {
            e.printStackTrace();
        }



    }



    public String getAnimetitleTitle() {
        return animetitle;
    }

    public void setAnimetitle(String title) {
        this.animetitle = animetitle;
    }

    public String getSynopsys() {
        return synopsys;
    }

    public void setSynopsys(String synopsys) {
        this.synopsys = synopsys;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    public void random(View view){

        Intent intent = new Intent(this, Random_Anime.class);
        super.startActivity(intent);
        super.finish();
    }
}
