package univ.acy.iut.monninj.project.random_anime;


import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;

public class Connexion extends Thread {

    private int id;
    private String ip;
    private Socket socket;
    private String anime;
    private Affichage affichage;
    private final static String TAG=Connexion.class.getName();

    public Connexion (int id, Affichage affichage){

        this.id=id;
        this.ip="192.168.1.13";
        this.affichage = affichage;
        super.start();

    }

    @Override
    public void run() {
        super.run();
        this.socket = new Socket();
        Inet4Address ipsrv=null;
        try {
            ipsrv = (Inet4Address) InetAddress.getByName(this.ip);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        InetSocketAddress endpoint=new InetSocketAddress(ipsrv, 8080);
        try {

            this.socket.connect(endpoint);
            Log.i(TAG,"Connexion");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            write(String.valueOf(this.id).getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] response = this.read();
        try {
            this.socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.anime = new String(response);
        Log.i(TAG,"anime = "+anime);
        this.affichage.take(this.anime);

        this.affichage.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG,"NEW THREAD");

                affichage.AnimeTitre.setText(affichage.getAnimetitleTitle());
                affichage.AnimeSynopsys.setText(affichage.getSynopsys());
                affichage.AnimeImage.setImageBitmap(affichage.ImageDL);
            }
        });

    }

    public void write(byte[] request) throws IOException {

        OutputStream outputStream= this.socket.getOutputStream();
        outputStream.write(request);
        outputStream.flush();

    }

    public byte[] read(){

        byte[] response=new byte [100000];
        try {
            this.socket.getInputStream().read(response);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }
}
